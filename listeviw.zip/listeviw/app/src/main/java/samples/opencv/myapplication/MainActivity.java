package samples.opencv.myapplication;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ListView listview;
    private ArrayList<achat> list;
    private ArrayList<achat> nv_liste;
    private ArrayList<ArrayList<achat>> list_parent;
    private adaptater adapter;


    private Button b;
    private EditText editT,editT2;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview=findViewById(R.id.listview);
        b=findViewById(R.id.button);
        editT=findViewById(R.id.editText);
        editT2=findViewById(R.id.editText2);

        b.setOnClickListener(this);


        list=new ArrayList<achat>();
        list.add(new achat("kg farine",10));
        list.add(new achat("huile l",10));
        list.add(new achat("Tomates kg ",4));
        list.add(new achat("levures",10));
        list.add(new achat("Eau l ",10));
        list.add(new achat("Extrait de vanille",1));
        list.add(new achat("poivre noir g",100));
        list.add(new achat("Olives noir g",200));


        adapter = new adaptater(this,list);
        listview.setAdapter(adapter);





    }

    @Override
    public void onClick(View v) {

        if (!(editT2.getText().toString().isEmpty()) &&!(editT.getText().toString().isEmpty())){

            list.add(new achat(editT.getText().toString(),Double.valueOf(editT2.getText().toString())));



            editT.setText("");
            editT2.setText("");



            listview.setAdapter(adapter);


        }




    }

}



