package samples.opencv.myapplication;
import android.app.Activity;
        import android.app.AlertDialog;
        import android.content.Context;
        import android.content.DialogInterface;
        import android.util.Log;
        import android.view.LayoutInflater;
        import android.view.View;
        import android.view.ViewGroup;
        import android.widget.ArrayAdapter;
        import android.widget.EditText;
        import android.widget.ImageButton;
        import android.widget.TextView;
        import android.widget.Toast;

        import androidx.annotation.NonNull;

        import java.util.ArrayList;

public class adaptater  extends ArrayAdapter<achat> {
    Activity context;
    ArrayList<achat> liste;
    ImageButton supp,edit;
    TextView textView,text;


    public adaptater(@NonNull Context context, ArrayList<achat> liste) {

        super(context, R.layout.achat,liste);
        this.context= (Activity) context;
        this.liste=liste;

    }

    public View getView(final int position, View convert, ViewGroup parent)
    {

        LayoutInflater inflate = context.getLayoutInflater();
        convert=inflate.inflate(R.layout.achat,null);




        textView=convert.findViewById(R.id.textview);
        text=convert.findViewById(R.id.text2);
        textView.setText(liste.get(position).getAchat().toString());
        text.setText(String.valueOf(liste.get(position).getquantite()));
        supp=convert.findViewById(R.id.imageButton);
        edit=convert.findViewById(R.id.imageButton2);

        supp.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.i("erreur2","ca va ca marche onclilk");
               liste.remove(position);
                notifyDataSetChanged();
                Toast.makeText(context,"votre produit achats a etais bien supprimer ",Toast.LENGTH_LONG).show();
            }
        });
        Log.i("erreur3","on est avent le onclik2");
        edit.setOnClickListener(new View.OnClickListener() {
            /**
             * Called when a view has been clicked.
             *
             * @param v The view that was clicked.
             */
            @Override
            public void onClick(View v) {
                modif_item(position);


            }
        });
        return convert;
    }
    public void modif_item( final int position){

        final EditText edit_achat,edit_quantite;
        AlertDialog.Builder Builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = context.getLayoutInflater();
        View view_modif = inflater.inflate(R.layout.modif,null);


        Builder.setView(view_modif);
        edit_achat=view_modif.findViewById(R.id.achat_nv);
        edit_quantite=view_modif.findViewById(R.id.quantite_nv);
        Builder.setNegativeButton("annuler", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        Builder.setPositiveButton("Modifier ", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                if (edit_achat.getText().toString().isEmpty() && edit_quantite.getText().toString().isEmpty()) {
                    Toast.makeText(context,"il faut rempli",Toast.LENGTH_LONG).show();
                }
                else {
                    if (!edit_achat.getText().toString().isEmpty()){
                        double qt=liste.get(position).getquantite();
                        liste.set(position,new achat(edit_achat.getText().toString(),qt));

                    }
                    if (!edit_quantite.getText().toString().isEmpty()){
                        String achat=liste.get(position).getAchat();
                        liste.set(position,new achat(achat,Double.valueOf(edit_quantite.getText().toString())));

                    }
                    notifyDataSetChanged();
                    Toast.makeText(context,"votre modification  est bien fait",Toast.LENGTH_LONG).show();

                    dialog.dismiss();
                }

            }
        });


        Builder.show();




    }






}
