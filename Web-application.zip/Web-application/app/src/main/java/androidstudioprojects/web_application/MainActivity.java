package androidstudioprojects.web_application;

import android.os.Bundle;

import android.support.v7.app.AppCompatActivity;

import android.view.View;

import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    private WebView webView;
    public void loading(View view){
        EditText urledit=(EditText)findViewById(R.id.editText);
        webView=(WebView)findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient());
        webView.loadUrl("http://"+urledit.getText().toString());
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView=(WebView)findViewById(R.id.webview);
        webView.setWebViewClient(new WebViewClient(){
            public void onPageFinished(WebView view,String url){
                EditText urledit=(EditText)findViewById(R.id.editText);
                urledit.setText(view.getUrl());
            }
        });
        webView.loadUrl("http://www.google.dz");
    }




    }

