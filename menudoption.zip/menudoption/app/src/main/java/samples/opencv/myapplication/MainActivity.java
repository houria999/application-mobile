package samples.opencv.myapplication;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private ListView listview;
    private ArrayList<achat> lista;
    private ArrayList<achat>  ajoute_liste ;
    private ArrayList<ArrayList<achat>> list_ancien;
    private adaptater adapter;
    TextView textAffiche;
    Toast toast;
    int posit;


    private Button b;
    private EditText editT,editT2;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview=findViewById(R.id.listview);
        b=findViewById(R.id.button);
        editT=findViewById(R.id.editText);
        editT2=findViewById(R.id.editText2);

        b.setOnClickListener(this);
        textAffiche=findViewById(R.id.textAffiche);
        this.registerForContextMenu(this.textAffiche);
        list_ancien=new ArrayList<ArrayList<achat>>();
        posit=0;
        view_liste();

        lista=new ArrayList<achat>();
        lista.add(new achat("kg farine",10));
        lista.add(new achat("huile l",10));
        lista.add(new achat("Tomates kg ",4));
        lista.add(new achat("levures",10));
        lista.add(new achat("Eau l ",10));
        lista.add(new achat("Extrait de vanille",1));
        lista.add(new achat("poivre noir g",100));
        lista.add(new achat("Olives noir g",200));


        adapter = new adaptater(this,lista);
        listview.setAdapter(adapter);





    }
    public boolean onCreateOptionsMenu(Menu menu){
        this.getMenuInflater().inflate(R.menu.menu1,menu);



        return true;
    }
    public boolean onOptionsItemSelected(MenuItem item){

        int id =item.getItemId();
        if (id ==R.id.item1){
            //ajoute une novell list
            ajoute_liste=new ArrayList<achat>();
            if (list_ancien.size()>= 3){
                Toast.makeText(this,"tu ne peut pas cree plus de 3 liste ",Toast.LENGTH_LONG).show();

            }
            else {
                list_ancien.add(ajoute_liste);
                adapter = new adaptater(this, get_liste_cournt(list_ancien.size() - 1));
                view_liste();
                listview.setAdapter(adapter);
                Toast.makeText(this,"votre creation de la nouvel liste est bien fini",Toast.LENGTH_LONG).show();

            }
        }
        if (id ==R.id.item2){

            final AlertDialog.Builder builder_Effacer =new  AlertDialog.Builder(this);
            LayoutInflater inflater = this.getLayoutInflater();
            View view_modif = inflater.inflate(R.layout.vide_list,null);
            builder_Effacer.setView(view_modif);

            builder_Effacer.setPositiveButton("oui", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    get_liste_cournt(list_ancien.size()-1).clear();
                    adapter = new adaptater(MainActivity.this,get_liste_cournt(list_ancien.size()-1));

                   //Toast.makeText(this,"Vous avez supprimé la liste",Toast.LENGTH_LONG).show();

                    listview.setAdapter(adapter);
                    dialog.dismiss();

                }
            });
            Toast.makeText(this,"Vous avez supprimé la liste",Toast.LENGTH_LONG).show();
            builder_Effacer.setNegativeButton("non", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {

                    dialog.dismiss();
                }
            });
            builder_Effacer.show();


        }
        if (id ==R.id.item3){
            AlertDialog.Builder dilog=new AlertDialog.Builder(this);
            dilog.setMessage("Achats app devloper pur vous");
            dilog.setTitle("A propose");
            dilog.setNeutralButton("oki",null);
            dilog.show();

        }


        return  true;
    }


    @Override
    public void onClick(View v) {

        if (!(editT2.getText().toString().isEmpty()) && !(editT.getText().toString().isEmpty())) {

            list.add(new achat(editT.getText().toString(), Double.valueOf(editT2.getText().toString())));


            editT.setText("");
            editT2.setText("");


            listview.setAdapter(adapter);


        }

    }
    public void view_liste (){
            textAffiche.setText("liste "+posit);
        }
        public ArrayList<achat> get_liste_cournt(int position){
            this.posit=position;

            if (position>=0 && position<=list_ancien.size()-1){


                return list_ancien.get(position);
            }
            return null;
        }




    }
    /*@Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        this.getMenuInflater().inflate(R.menu.menulist,menu);
    }
    public boolean onContextItemSelected(MenuItem item) {
        int i = item.getItemId();
        if (i == R.id.item1) {
            if (get_liste_cournt(0) == null) {
                Toast.makeText(this,"cette liste n'existe pas deja ",Toast.LENGTH_LONG).show();
                else {
                adapter = new adaptater(this, get_liste_cournt(0));
                    view_liste();
                listview.setAdapter(adapter);

                    Toast.makeText(this,"vous etre dans la liste 1",Toast.LENGTH_LONG).show();
            }
        }
        if (i == R.id.item2) {
            if (get_liste_cournt(1) == null) {
                Toast.makeText(this,"cette liste n'existe pas deja ",Toast.LENGTH_LONG).show();
            } else {
                adapter =  new adaptater(this, get_liste_cournt(1));
                view_liste();
                listview.setAdapter(adapter);
                Toast.makeText(this,"vous etre dans la liste 2",Toast.LENGTH_LONG).show();
            }
        }
        if (i == R.id.item3) {
            if (get_liste_cournt(2) == null) {
                Toast.makeText(this,"cette liste n'existe pas deja ",Toast.LENGTH_LONG).show();
            } else {
                adapter = new adaptater(this, get_liste_cournt(2));
                view_liste();
                listview.setAdapter(adapter);
                Toast.makeText(this,"vous etre dans la liste 3",Toast.LENGTH_LONG).show();
            }
        }
        return true;


    }*/






